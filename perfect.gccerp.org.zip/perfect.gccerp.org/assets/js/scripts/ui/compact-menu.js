/*=========================================================================================
    File Name: compact-menu.js
    Description: Compact menu page level only
    ----------------------------------------------------------------------------------------
    Item Name: Chameleon Admin - Modern Bootstrap 4 WebApp & Dashboard HTML Template + UI Kit
    Version: 1.2
    Author: ThemeSelection
    Author URL: https://themeselection.com/
==========================================================================================*/
$(document).ready(function(){
    setTimeout(function(){
        $.app.menu.collapse();
    }, 100);
});