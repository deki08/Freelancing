//  Notifications & messages scrollable
if($('.sidebar-fixed').length > 0){
	var sidebar_fixed = new PerfectScrollbar('.sidebar-fixed');
}