package com.multipixeltec.dcservice.repository;

import com.multipixeltec.dcservice.model.RefValue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RefValueRepository extends JpaRepository<RefValue, Long> {
}